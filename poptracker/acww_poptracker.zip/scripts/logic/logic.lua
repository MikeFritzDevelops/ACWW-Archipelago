-- ACWW PopTracker catchability logic
-- Generated from the Archipelago world's availability.py.

function has(code)
    return Tracker:ProviderCountForCode(code) > 0
end

function canCatchBugCommonButterfly()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugYellowButterfly()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugTigerButterfly()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september")) and (has("resource_pink_roses") or has("resource_red_roses"))
end

function canCatchBugPeacockButterfly()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september")) and (has("resource_black_roses") or has("resource_blue_roses") or has("resource_purple_roses"))
end

function canCatchBugMonarchButterfly()
    return has("access_net") and (has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugEmperorButterfly()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugAgriasButterfly()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugBirdwingButterfly()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugMoth()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugOakSilkMoth()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august"))
end

function canCatchBugHoneybee()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugBee()
    return has("access_net")
end

function canCatchBugLongLocust()
    return has("access_net") and (has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugMigratoryLocust()
    return has("access_net") and (has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugMantis()
    return has("access_net") and (has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugOrchidMantis()
    return has("access_net") and (has("month_august") or has("month_september") or has("month_october") or has("month_november")) and has("resource_white_roses")
end

function canCatchBugBrownCicada()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugRobustCicada()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugWalkerCicada()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugEveningCicada()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugLanternFly()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugRedDragonfly()
    return has("access_net") and (has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugDarnerDragonfly()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august"))
end

function canCatchBugBandedDragonfly()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugAnt()
    return has("access_net") and has("resource_spoiled_turnips")
end

function canCatchBugPondskater()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugSnail()
    return has("access_net") and (has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugCricket()
    return has("access_net") and (has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugBellCricket()
    return has("access_net") and (has("month_september") or has("month_october"))
end

function canCatchBugGrasshopper()
    return has("access_net") and (has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugMoleCricket()
    return has("access_net") and (has("month_january") or has("month_february") or has("month_march") or has("month_november") or has("month_december")) and has("access_shovel")
end

function canCatchBugWalkingstick()
    return has("access_net") and (has("month_july") or has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugLadybug()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_october"))
end

function canCatchBugFruitBeetle()
    return has("access_net") and (has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugScarabBeetle()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugDungBeetle()
    return has("access_net") and (has("month_january") or has("month_february") or has("month_december"))
end

function canCatchBugGoliathBeetle()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august")) and has("resource_coconut")
end

function canCatchBugFirefly()
    return has("access_net") and (has("month_june"))
end

function canCatchBugJewelBeetle()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugLonghornBeetle()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august"))
end

function canCatchBugSawStagBeetle()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugStagBeetle()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august"))
end

function canCatchBugGiantBeetle()
    return has("access_net") and (has("month_july") or has("month_august"))
end

function canCatchBugRainbowStagBeetle()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugDynastidBeetle()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugAtlasBeetle()
    return has("access_net") and (has("month_july") or has("month_august")) and has("resource_coconut")
end

function canCatchBugElephantBeetle()
    return has("access_net") and (has("month_july") or has("month_august")) and has("resource_coconut")
end

function canCatchBugHerculesBeetle()
    return has("access_net") and (has("month_july") or has("month_august")) and has("resource_coconut")
end

function canCatchBugFlea()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugPillBug()
    return has("access_net") and has("access_shovel")
end

function canCatchBugMosquito()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchBugFly()
    return has("access_net") and has("resource_spoiled_turnips")
end

function canCatchBugCockroach()
    return has("access_net")
end

function canCatchBugSpider()
    return has("access_net") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchBugTarantula()
    return has("access_net") and (has("month_june") or has("month_july") or has("month_august"))
end

function canCatchBugScorpion()
    return has("access_net") and (has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishBitterling()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_november") or has("month_december"))
end

function canCatchFishPaleChub()
    return has("access_fishing_rod")
end

function canCatchFishCrucianCarp()
    return has("access_fishing_rod")
end

function canCatchFishDace()
    return has("access_fishing_rod")
end

function canCatchFishBarbelSteed()
    return has("access_fishing_rod")
end

function canCatchFishCarp()
    return has("access_fishing_rod")
end

function canCatchFishKoi()
    return has("access_fishing_rod")
end

function canCatchFishGoldfish()
    return has("access_fishing_rod")
end

function canCatchFishPopeyedGoldfish()
    return has("access_fishing_rod")
end

function canCatchFishKillifish()
    return has("access_fishing_rod") and (has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august"))
end

function canCatchFishCrawfish()
    return has("access_fishing_rod") and (has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishFrog()
    return has("access_fishing_rod") and (has("month_may") or has("month_june") or has("month_july") or has("month_august"))
end

function canCatchFishFreshwaterGoby()
    return has("access_fishing_rod")
end

function canCatchFishLoach()
    return has("access_fishing_rod") and (has("month_march") or has("month_april") or has("month_may"))
end

function canCatchFishCatfish()
    return has("access_fishing_rod") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september") or has("month_october"))
end

function canCatchFishEel()
    return has("access_fishing_rod") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishGiantSnakehead()
    return has("access_fishing_rod") and (has("month_june") or has("month_july") or has("month_august"))
end

function canCatchFishBluegill()
    return has("access_fishing_rod")
end

function canCatchFishYellowPerch()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_march") or has("month_october") or has("month_november") or has("month_december"))
end

function canCatchFishBlackBass()
    return has("access_fishing_rod")
end

function canCatchFishPondSmelt()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_december"))
end

function canCatchFishSweetfish()
    return has("access_fishing_rod") and (has("month_july") or has("month_august"))
end

function canCatchFishCherrySalmon()
    return has("access_fishing_rod") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchFishChar()
    return has("access_fishing_rod") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchFishRainbowTrout()
    return has("access_fishing_rod") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchFishStringfish()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_december"))
end

function canCatchFishSalmon()
    return has("access_fishing_rod") and (has("month_september"))
end

function canCatchFishKingSalmon()
    return has("access_fishing_rod") and (has("month_september"))
end

function canCatchFishGuppy()
    return has("access_fishing_rod") and (has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchFishAngelfish()
    return has("access_fishing_rod") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september") or has("month_october"))
end

function canCatchFishPiranha()
    return has("access_fishing_rod") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishArowana()
    return has("access_fishing_rod") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishDorado()
    return has("access_fishing_rod") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishGar()
    return has("access_fishing_rod") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishArapaima()
    return has("access_fishing_rod") and (has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishSeaButterfly()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_december"))
end

function canCatchFishJellyfish()
    return has("access_fishing_rod") and (has("month_august"))
end

function canCatchFishSeahorse()
    return has("access_fishing_rod") and (has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchFishClownfish()
    return has("access_fishing_rod") and (has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishZebraTurkeyfish()
    return has("access_fishing_rod") and (has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchFishPufferfish()
    return has("access_fishing_rod") and (has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishHorseMackerel()
    return has("access_fishing_rod")
end

function canCatchFishBarredKnifejaw()
    return has("access_fishing_rod") and (has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_september") or has("month_october") or has("month_november"))
end

function canCatchFishSeaBass()
    return has("access_fishing_rod")
end

function canCatchFishRedSnapper()
    return has("access_fishing_rod")
end

function canCatchFishDab()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_march") or has("month_april") or has("month_october") or has("month_november") or has("month_december"))
end

function canCatchFishOliveFlounder()
    return has("access_fishing_rod")
end

function canCatchFishSquid()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_august") or has("month_december"))
end

function canCatchFishOctopus()
    return has("access_fishing_rod") and (has("month_january") or has("month_march") or has("month_april") or has("month_may") or has("month_june") or has("month_july") or has("month_september") or has("month_october") or has("month_november") or has("month_december"))
end

function canCatchFishFootballFish()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_march") or has("month_november") or has("month_december"))
end

function canCatchFishTuna()
    return has("access_fishing_rod") and (has("month_january") or has("month_february") or has("month_march") or has("month_november") or has("month_december"))
end

function canCatchFishBlueMarlin()
    return has("access_fishing_rod") and (has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishOceanSunfish()
    return has("access_fishing_rod") and (has("month_july") or has("month_august"))
end

function canCatchFishHammerheadShark()
    return has("access_fishing_rod") and (has("month_july") or has("month_august"))
end

function canCatchFishShark()
    return has("access_fishing_rod") and (has("month_june") or has("month_july") or has("month_august") or has("month_september"))
end

function canCatchFishCoelacanth()
    return has("access_fishing_rod")
end
